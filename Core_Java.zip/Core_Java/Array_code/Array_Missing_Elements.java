package org.Array;

import java.util.Scanner;

public class Array_Missing_Elements {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a[]=new int[6];
		System.out.println("Enter the Elements in array");
		for(int i=0;i<a.length;i++)
		{
			a[i]=s.nextInt();
		}
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		System.out.println("Missing elements are");
		for(int i=0;i<a.length-1;i++)
		{
			for(int j=a[i]+1;j<a[i+1];j++)
			{
				System.out.println(j);
			}
		}

	}

}
