import java.util.*;
public class TwoD_ArraySecondSmallest
{
public static void main(String x[])
{
 
  int i,j,min;
  Scanner s=new Scanner(System.in);
  System.out.println("Enter the elements in array");
  for(i=0;i<a.length;i++)
    
   

   
         
   
}  
}
