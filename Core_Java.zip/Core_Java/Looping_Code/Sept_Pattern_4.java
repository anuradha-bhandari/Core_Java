public class Sept_Pattern_4
{
public static void main(String x[])
{
int i,j;
boolean flag=true;
for(i=1;i<=5;i++)
{
  for(j=0;j<i;j++)
    {
	 System.out.printf("%d",(i+j)%2);
			   
	  

	}
 System.out.println("");

}
}
}