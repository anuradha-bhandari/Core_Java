//import java.util.*;
public class pattern1
{
public static void main(String x[])
{
 int i,j;
for(i=1;i<=10;i++)
{
    for(j=1;j<=10;j++)
                 {
                   // if(j<=i||j>=11-i)
                                         {
                                         System.out.println("*");
                                         }
                 /* else{
                        System.out.println(" ");

                       }*/

                  }
 System.out.println("\n");

}
}
}
