public class Sept_Pattern_1
{
public static void main(String x[])
{
int i,j;
for(i=1;i<=5;i++)
{
  for(j=1;j<=11-2*i;j++)
    {
	 System.out.printf("*");
	}
 System.out.println("");

}
}
}