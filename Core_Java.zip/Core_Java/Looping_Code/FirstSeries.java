package org.series_code;

public class FirstSeries {

	public static void main(String[] args) {
		int c=1;
		for(int i=1;i<=10;i++)
		{
			System.out.println(c);
			c=c+3;
		}

	}

}
