package org.series_code;

public class Geometric_ratio_2 {

	public static void main(String[] args) {
		int c=1;
		for(int i=1;i<=10;i++)
		{
			System.out.println(c);
			c=c*2;
		}
	}

}
