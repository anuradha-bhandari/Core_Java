import java.util.*;
public class FunctionPrintAtoZAlpha
{
public static void main(String x[])
{
System.out.println(" Print A to Z alphabets "); 
Alphabet();
}
public static void Alphabet()
{
 for(char ch='A';ch<='Z';ch++)
{
  System.out.println(ch);

}
return;

}
}