/*Q7. WAP to fetch folder within folder and its file from particular path and display output like */

import java.io.*;
public class  Filehandling_23JanQue7
{
  public static void main(String x[])
  {
  }
} 
  