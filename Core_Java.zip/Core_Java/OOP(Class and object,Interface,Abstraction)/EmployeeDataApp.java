import java.util.*;
public class EmployeeDataApp
{
public static void main (String x[])
{
Scanner xyz=new Scanner(System.in);
System.out.println("Enter Name");
String name=xyz.nextLine();
System.out.println("Enter id");
int id =xyz.nextInt();
System.out.println("Enter salary");
long salary=xyz.nextLong();

System.out.println(" Name is "+name);
System.out.println("id is"+id);
System.out.println("salary is"+salary);
}
}





